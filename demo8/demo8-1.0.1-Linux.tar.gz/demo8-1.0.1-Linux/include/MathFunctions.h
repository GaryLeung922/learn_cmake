//
// Created by liangjiaqi on 9/30/20.
//

#ifndef LEARN_CMAKE_MATHFUNCTIONS_H
#define LEARN_CMAKE_MATHFUNCTIONS_H

#endif //LEARN_CMAKE_MATHFUNCTIONS_H
#ifndef POWER_H
#define POWER_H

extern double power(double base, int exponent);

#endif